package com.selimhorri.app;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceApplicationTests {
	
	
	
}






