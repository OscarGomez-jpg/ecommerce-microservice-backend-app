# Taller 2 - Pruebas Implementadas

## Estructura del ZIP

Este archivo contiene todas las pruebas implementadas para el Taller 2 de Ingeniería de Software V.

### 📁 Contenido

#### 1. Pruebas Unitarias (`*/src/test/java/`)

Pruebas unitarias de cada microservicio usando JUnit y Mockito:

- **order-service/src/test/java/com/selimhorri/app/service/OrderServiceTest.java**
  - Tests de creación de órdenes
  - Tests de actualización de órdenes
  - Tests de consulta de órdenes por usuario
  - Tests de eliminación de órdenes
  - Tests de consulta de órdenes por ID

- **payment-service/src/test/java/com/selimhorri/app/service/PaymentServiceTest.java**
  - Tests de procesamiento de pagos
  - Tests de actualización de estado de pago
  - Tests de consulta de pagos
  - Tests de validación de datos de pago

- **product-service/src/test/java/com/selimhorri/app/service/ProductServiceTest.java**
  - Tests de creación de productos
  - Tests de actualización de productos
  - Tests de consulta de productos
  - Tests de eliminación de productos
  - Tests de búsqueda de productos

- **shipping-service/src/test/java/com/selimhorri/app/service/ShippingServiceTest.java**
  - Tests de creación de envíos
  - Tests de actualización de estado de envío
  - Tests de consulta de envíos por orden
  - Tests de eliminación de envíos

- **user-service/src/test/java/com/selimhorri/app/service/UserServiceTest.java**
  - Tests de registro de usuarios
  - Tests de autenticación
  - Tests de actualización de perfil
  - Tests de consulta de usuarios
  - Tests de eliminación de usuarios

#### 2. Pruebas E2E con Cypress (`tests/e2e/cypress/e2e/`)

Pruebas End-to-End que validan flujos completos de usuario:

- **01-complete-checkout-flow.cy.js**
  - Flujo completo de compra desde navegación hasta pago
  - Validación de carrito de compras
  - Validación de proceso de checkout

- **02-user-registration-purchase.cy.js**
  - Registro de nuevo usuario
  - Login
  - Primera compra del usuario

- **03-product-search-favourite.cy.js**
  - Búsqueda de productos
  - Agregar productos a favoritos
  - Gestión de lista de favoritos

- **04-order-tracking.cy.js**
  - Creación de orden
  - Consulta de estado de orden
  - Tracking de envío

- **05-payment-refund-flow.cy.js**
  - Proceso de pago
  - Solicitud de reembolso
  - Validación de reembolso completado

**Configuración:**
- `cypress.config.js` - Configuración de Cypress
- `cypress/support/commands.js` - Comandos personalizados
- `cypress/support/e2e.js` - Configuración global

#### 3. Pruebas de Rendimiento con Locust (`tests/performance/`)

Pruebas de carga y estrés que simulan usuarios reales:

- **locustfile.py** - Definición de escenarios de carga
  - **EcommerceUserBehavior** (PurchasingUser):
    - Navegación de productos
    - Consulta de producto específico
    - Creación de órdenes
    - Consulta de órdenes de usuario

  - **BrowsingUser**:
    - Navegación general de productos
    - Consulta de productos específicos
    - Navegación de usuarios

  - **AdminUser**:
    - Gestión de productos
    - Consulta de órdenes
    - Gestión de usuarios

- **requirements.txt** - Dependencias de Python
- **reports/** - Directorio para reportes HTML generados

#### 4. Script de Población de Datos (`scripts/`)

- **populate-test-data.sh**
  - Script bash para poblar la base de datos antes de ejecutar pruebas
  - Crea 20 productos de ejemplo
  - Crea 10 usuarios de ejemplo
  - Crea 5 órdenes de ejemplo
  - Valida disponibilidad de servicios

### 🔧 Tecnologías Utilizadas

- **JUnit 5** - Framework de pruebas unitarias para Java
- **Mockito** - Framework de mocking para Java
- **Cypress** - Framework de pruebas E2E
- **Locust** - Framework de pruebas de rendimiento en Python
- **Mochawesome** - Generador de reportes HTML para Cypress

### 📊 Integración con Pipeline

Todas estas pruebas están integradas en el pipeline de Jenkins:

**Pipeline DEV (rama `dev`):**
- Build de servicios
- Ejecución de pruebas unitarias
- Análisis de código con SonarQube

**Pipeline PROD (rama `master`):**
- Build de servicios
- Ejecución de pruebas unitarias
- Análisis de código con SonarQube
- Población de datos de prueba
- Ejecución de pruebas E2E con Cypress
- Ejecución de pruebas de rendimiento con Locust
- Despliegue en Kubernetes (Minikube)

### 📝 Notas

- Todas las pruebas validan funcionalidades existentes del sistema
- Las pruebas E2E y de rendimiento requieren que los servicios estén desplegados
- Los reportes HTML se generan automáticamente en el pipeline
- Las pruebas están configuradas para trabajar con API Gateway en el puerto 30080
